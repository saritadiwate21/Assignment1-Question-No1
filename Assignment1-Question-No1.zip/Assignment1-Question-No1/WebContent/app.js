var username,password1,cpassword1,firstname,lastname,emailid,phone,location1;

username = document.forms["myForm"]["uname"].value;
password1 = document.forms["myForm"]["password"].value;
cpassword1 = document.forms["myForm"]["cpassword"].value;
firstname = document.forms["myForm"]["fname"].value;
lastname = document.forms["myForm"]["lname"].value;
emailid = document.forms["myForm"]["email"].value;
phone = document.forms["myForm"]["phoneno"].value;
location1 = document.forms["myForm"]["location"].value;


document.getElementById("resetbtn").addEventListener("click",function(){

	document.getElementById("myForm").reset();
});
document.getElementById("savebtn").addEventListener("click",function(){

});
function resetForm(){
	document.getElementById("myForm").reset();
}

function validateForm() {

	username = document.forms["myForm"]["uname"].value;
	password1 = document.forms["myForm"]["password"].value;
	cpassword1 = document.forms["myForm"]["cpassword"].value;
	firstname = document.forms["myForm"]["fname"].value;
	lastname = document.forms["myForm"]["lname"].value;
	emailid = document.forms["myForm"]["email"].value;
	phone = document.forms["myForm"]["phoneno"].value;
	location1 = document.forms["myForm"]["location"].value;

	
    if (username == "") {
        document.getElementById("unameError").innerHTML="User name must be filled out"
    	 //alert("Name must be filled out");
    	return false;
    }
    else
    	{
    	document.getElementById("unameError").innerHTML="";
    	}
    
    if (password1 == "") {
        document.getElementById("passwordError").innerHTML="password must be filled out"
    	 //alert("pass must be filled out");
    	return false;
    }
    else
	{
	document.getElementById("passwordError").innerHTML="";
	}
    
    if (cpassword1!=password1) {
        document.getElementById("cpasswordError").innerHTML="Password & confirm password must be same"
        return false;
    }
    else
	{
	document.getElementById("cpasswordError").innerHTML="";
	}
    var alphaExp = /^[a-zA-Z]+$/;
    if (!firstname.match(alphaExp)) {
        document.getElementById("fnameError").innerHTML="first name must containg letters only"
        return false;
    }
    else
	{
	document.getElementById("fnameError").innerHTML="";
	}
    
    if (!lastname.match(alphaExp)) {
        document.getElementById("lnameError").innerHTML="last name must containg letters only"
        return false;
    }
    else
	{
	document.getElementById("lnameError").innerHTML="";
	}
    var atposition=emailid.indexOf("@");  
    var dotposition=emailid.lastIndexOf("."); 
    if (atposition<1 || dotposition<atposition+2 || dotposition+2>=emailid.length) {
        document.getElementById("emailError").innerHTML="email must be valid"
        return false;
    }
    else
	{
	document.getElementById("emailError").innerHTML="";
	}
    
    if (phone.length!=10) {
        document.getElementById("phonenoError").innerHTML="phone number must be filled out"
        return false;
    }
    else
	{
	document.getElementById("phonenoError").innerHTML="";
	}
    
 
    if (!location1.match(alphaExp)) {
        document.getElementById("locationError").innerHTML="location must containg letters only"
        return false;
    }
    else
	{
	document.getElementById("locationError").innerHTML="";
	}
    	   
    
return true;
   
}


function savedata(){
	username = document.forms["myForm"]["uname"].value;
	password1 = document.forms["myForm"]["password"].value;
	cpassword1 = document.forms["myForm"]["cpassword"].value;
	firstname = document.forms["myForm"]["fname"].value;
	lastname = document.forms["myForm"]["lname"].value;
	emailid = document.forms["myForm"]["email"].value;
	phone = document.forms["myForm"]["phoneno"].value;
	location1 = document.forms["myForm"]["location"].value;
	alert("hi "+username);
	document.getElementById("myForm").submit();
}