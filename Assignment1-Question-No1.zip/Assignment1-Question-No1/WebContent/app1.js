var username,password1,cpassword1,firstname,lastname,emailid,phone,location1;

username = document.forms["myForm"]["uname"].value;
password1 = document.forms["myForm"]["password"].value;
cpassword1 = document.forms["myForm"]["cpassword"].value;
firstname = document.forms["myForm"]["fname"].value;
lastname = document.forms["myForm"]["lname"].value;
emailid = document.forms["myForm"]["email"].value;
phone = document.forms["myForm"]["phoneno"].value;
location1 = document.forms["myForm"]["location"].value;


document.getElementById("resetbtn").addEventListener("click",function(){

	document.getElementById("myForm").reset();
});
document.getElementById("savebtn").addEventListener("click",function(){

});
function resetForm(){
	document.getElementById("myForm").reset();
}

function validateForm() {

	username = document.forms["myForm"]["uname"].value;
	password1 = document.forms["myForm"]["password"].value;
	cpassword1 = document.forms["myForm"]["cpassword"].value;
	firstname = document.forms["myForm"]["fname"].value;
	lastname = document.forms["myForm"]["lname"].value;
	emailid = document.forms["myForm"]["email"].value;
	phone = document.forms["myForm"]["phoneno"].value;
	location1 = document.forms["myForm"]["location"].value;

	
    if (username == "") {
        document.getElementById("unameError").innerHTML="User name must be filled out"
    	 //alert("Name must be filled out");
    	return false;
    }
    else
    	{
    	document.getElementById("unameError").innerHTML="";
    	}
    
    if (password1 == "") {
        document.getElementById("passwordError").innerHTML="password must be filled out"
    	 //alert("pass must be filled out");
    	return false;
    }
    else
	{
	document.getElementById("passwordError").innerHTML="";
	}
    
    if (cpassword1!=password1) {
        document.getElementById("cpasswordError").innerHTML="Password & confirm password must be same"
        return false;
    }
    else
	{
	document.getElementById("cpasswordError").innerHTML="";
	}
    var alphaExp = /^[a-zA-Z]+$/;
    if (!firstname.match(alphaExp)) {
        document.getElementById("fnameError").innerHTML="first name must containg letters only"
        return false;
    }
    else
	{
	document.getElementById("fnameError").innerHTML="";
	}
    
    if (!lastname.match(alphaExp)) {
        document.getElementById("lnameError").innerHTML="last name must containg letters only"
        return false;
    }
    else
	{
	document.getElementById("lnameError").innerHTML="";
	}
    var atposition=emailid.indexOf("@");  
    var dotposition=emailid.lastIndexOf("."); 
    if (atposition<1 || dotposition<atposition+2 || dotposition+2>=emailid.length) {
        document.getElementById("emailError").innerHTML="email must be valid"
        return false;
    }
    else
	{
	document.getElementById("emailError").innerHTML="";
	}
    
    if (phone.length!=10) {
        document.getElementById("phonenoError").innerHTML="phone number must be filled out"
        return false;
    }
    else
	{
	document.getElementById("phonenoError").innerHTML="";
	}
    
 
    if (!location1.match(alphaExp)) {
        document.getElementById("locationError").innerHTML="location must containg letters only"
        return false;
    }
    else
	{
	document.getElementById("locationError").innerHTML="";
	}
    	   
    
return true;
   
}


$(document).ready(function() {
	$("#savebtn").click(function() {
	var uname = $("#uname").val();
	var password = $("#password").val();
	var cpassword = $("#cpassword").val();
	
	var fname = $("#fname").val();
	var lname = $("#lname").val();
	var email = $("#email").val();
	var phoneno = $("#phoneno").val();
	
	var location = $("#location").val();
	//if (uname == '' || email == '' || phoneno == '' || password == '' || cpassword == ''||fname==''||lname==''||location=='') {
	if(!validateForm()){
	//alert("Insertion Failed Some Fields are Blank....!!");
	} else {
	// Returns successful data submission message when the entered information is stored in database.
	$.post("Save.jsp", {
		 uname :uname,
		 password:password ,
		 cpassword:cpassword ,
		
		 fname:fname ,
		 lname:lname ,
		 email:email ,
		 phoneno :phoneno,
		
		 location :location
		
	}, function(data) {
$("#successmsg").text(data);

showTable();
	$('#myForm')[0].reset(); // To reset form fields
	});
	}
	});
	
	
	
	});
function showTable(){
	   $.ajax({    //create an ajax request to load_page.php
	        type: "GET",
	        url: "getData.jsp",             
	        dataType: "html",   //expect html to be returned                
	        success: function(response){
	        	$("#succestble").html(response);
	           console.log(response);
	            //alert(response);
	        }

	    });
}
function myFunc(e){
	
    var tr = $('#myTable').find('tr');
    var arr= [];

    tr.bind('click', function(event) {
        var values = '';
       
        var tds = $(this).find('td');
    
        $.each(tds, function(index, item) {
           values = values + '' + '' + '' + item.innerHTML + '';
    //    values = index+" "+item.innerHTML;
       
        arr.push(item.innerHTML);
        });
       
       // console.log(values);
       console.log("Username "+arr[0]);
       var uname=arr[0];
       var pass = arr[1];
       var first = arr[2];
       var last = arr[3];
       var email = arr[4];
       var phone = arr[5];
       var loc  = arr[6];
      
   
       window.open("update.jsp?uname="+uname+"&pass="+pass+"&first="+first+"&last="+last+"&email="+email+"&phone="+phone+"&loc="+loc);
       tr.off("click");
});
   
    
}
function deleteData(){
	
    var tr = $('#myTable').find('tr');
    var arr= [];

    tr.bind('click', function(event) {
        var values = '';
       
        var tds = $(this).find('td');
    
        $.each(tds, function(index, item) {
           values = values + '' + '' + '' + item.innerHTML + '';
    //    values = index+" "+item.innerHTML;
       
        arr.push(item.innerHTML);
        });
       
       // console.log(values);
       console.log("Username "+arr[0]);
       var uname = arr[0];
   	$.post("deleteData.jsp", {
		 uname :uname
		
	}, function(data) {
//console.log(data);
		//$("#succesdelete").text(data);
		alert(data);
	});       
       tr.off("click");
});

}